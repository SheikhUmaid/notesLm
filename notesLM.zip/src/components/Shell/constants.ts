import { routerType } from 'config/router'
import { RouterType } from 'models/router'

export const allowAdvancedRoomLinkSharing = routerType === RouterType.BROWSER
