export enum QueryKey {
  TURN_SERVER = 'TURN_SERVER',
}
