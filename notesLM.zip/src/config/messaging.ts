export const messageCharacterSizeLimit = 10_000
export const messageTranscriptSizeLimit = 150
export const verificationTimeout = 10_000
