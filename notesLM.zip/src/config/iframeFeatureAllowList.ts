export const iframeFeatureAllowList = [
  'camera',
  'microphone',
  'display-capture',
  'fullscreen',
]
