export const communityRoomNames = [
  'buy-and-sell',
  'crypto',
  'hacking',
  'leaks',
  'news',
  'organize',
  'politics',
  'resist',
]
