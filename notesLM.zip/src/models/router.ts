export enum RouterType {
  BROWSER = 'browser',
  HASH = 'hash',
}
