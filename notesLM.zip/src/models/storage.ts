export enum PersistedStorageKeys {
  USER_SETTINGS = 'userSettings',
}
